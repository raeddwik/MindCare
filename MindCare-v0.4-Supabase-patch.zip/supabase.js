// MindCare v0.4 — Supabase client configuration
// IMPORTANT: use only the Publishable/anon key in this public frontend.
// NEVER place a service_role/secret key here.

const SUPABASE_URL = 'https://ieicwzkrngumuvrhlgpu.supabase.co';
const SUPABASE_PUBLISHABLE_KEY = 'REPLACE_WITH_YOUR_PUBLISHABLE_KEY';

if (!window.supabase) {
  console.error('Supabase JS library was not loaded.');
} else {
  window.mindcareSupabase = window.supabase.createClient(
    SUPABASE_URL,
    SUPABASE_PUBLISHABLE_KEY
  );
}
