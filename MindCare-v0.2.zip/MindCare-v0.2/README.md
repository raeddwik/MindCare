# MindCare v0.2

Arabic RTL PWA prototype for mental-health session booking.

## Included
- 30/60 minute sessions
- Date/time availability
- Conflict checking
- Client booking + consent
- Local appointments
- Prototype admin for availability/pricing
- PWA manifest + offline service worker

## Important
This is a prototype. Data is stored in browser localStorage. Do NOT use it for real patient/clinical data until a secure backend, authentication/authorization, server-side validation, encryption, audit logging, privacy controls and backups are implemented.

## Run
Serve the folder through HTTP/HTTPS, e.g. `python3 -m http.server 8000`, then open `http://localhost:8000`.
